# geom handoff package

You are building the `geom` crate for nyx (a Rust finite-element application). You do not have the nyx repository; this package holds everything you need.

Read in this order:
1. `docs/GEOM_HANDOFF.md`   - your brief: scope, decisions already made, API contract, tests, order of work. Where it conflicts with the architecture doc, it wins.
2. `docs/GEOMETRY_ARCHITECTURE.md` - the design and the reasons (what the current code does wrong, the CSG-over-B-rep proposal, selectors, mesher handoff).
3. `nyx_reference/` - read-only snapshots of the nyx files the brief points to, at their original relative paths (nyx main 54b8829):
   - `crates/femcore/src/mesher.rs`, `mesher3d.rs`: the current 2D/3D meshers (shapes, solids, surfaces, label rules, `conform_chains`)
   - `crates/femcore/src/mesh.rs`, `cellmesh.rs`: `SimplexMesh`, the contract with the solvers
   - `crates/femcore/src/problem.rs`: where integer labels are consumed (`Bc.labels`, `Materials`, `Periodic`, `inactive`)
   - `crates/femcore/src/fem.rs`: `geometry()`, the constant-Jacobian element geometry (the later curved-cell target; not your job)
   - `crates/femcore/src/expr.rs`: expression grammar to mirror (you cannot depend on femcore)
   - `crates/femcore/src/xmlio.rs`: how any serde value is written as XML (your types must round-trip through it)
   - `crates/femcore/src/usecases/{soi,bragg}.rs`, `chips.rs`: geometries your golden models must reproduce
   - `crates/femcore/src/meshers/adapt/geom.rs`, `pml.rs`, `meshers/interop.rs`: the geometry-oracle seam and the structured PML builder
   - `crates/app/src/state.rs`: the app's current `Geometry` enum and bbox `Region` relabel
   - `crates/femcore/tests/mesher.rs`, `mesher3d.rs`: existing mesher tests (what must keep working through the new path)
   - `docs/`: HOW_IT_WORKS.md, photonic_use_cases.md, chip_report.md (reference numbers); `README.md`, `Cargo.toml` files: repo conventions and versions

Notes:
- Nothing in `nyx_reference/` is to be edited or built; it is context. Your deliverable is a new `crates/geom` that depends only on `serde` (optional `rayon`, dev `serde_json` and `proptest`; the `robust` crate is acceptable for exact 2D predicates, nyx already uses it through `spade`).
- Rust 1.84+, edition 2021, SI units, f64. Keep it clippy-clean (`-D warnings`).
- The brief says to "trust the code over the docs" where they disagree; the reference files are the code.
- Deliver step by step (A to D in section 11 of the brief) with golden JSON files and a CHANGELOG line each time.
